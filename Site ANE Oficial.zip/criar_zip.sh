#!/bin/bash
cd dist
zip -r ../ane2026-completo.zip . -q
cd ..
echo "ZIP criado com sucesso: ane2026-completo.zip"
