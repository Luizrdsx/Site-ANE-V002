#!/bin/bash
cd dist
zip -r ../site-ane2026-final.zip .
cd ..
